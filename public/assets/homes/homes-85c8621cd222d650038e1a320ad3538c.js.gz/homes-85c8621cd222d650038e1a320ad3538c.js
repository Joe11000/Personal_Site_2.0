$(function(){
  alert('homes/homes.js Loaded')
});
